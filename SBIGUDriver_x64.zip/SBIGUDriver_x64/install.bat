batch@echo off
echo Installation of x64 SBIG ST-402 (manually signed)
echo =========================================================

:: Verification droits admin
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: you need Administrator priliveges. Execute the script from an elevated prompt.
    pause
    exit /b 1
)

echo.
echo [1/6] Configuring bcdedit...
bcdedit /set testsigning on
bcdedit /set loadoptions DISABLE_INTEGRITY_CHECKS
bcdedit /set hypervisorlaunchtype off

echo.
echo [2/6] Installing the test certificate...
certutil -addstore ROOT SBIGTest.cer
certutil -addstore TRUSTEDPUBLISHER SBIGTest.cer

echo.
echo [3/6] Copying the signed driver...
takeown /f "C:\Windows\System32\drivers\sbigu64.sys" >nul 2>&1
icacls "C:\Windows\System32\drivers\sbigu64.sys" /grant *S-1-5-32-544:F
copy /y "%~dp0sbigu64.sys" "C:\Windows\System32\drivers\sbigu64.sys"

echo.
echo [4/6] Installing driver package...
pnputil /add-driver "%~dp0DriverStore\sbigu64c.inf" /install

echo.
echo [5/6] Copying to DriverStore...
for /d %%D in ("C:\Windows\System32\DriverStore\FileRepository\sbigu64c.inf_amd64_*") do (
    takeown /f "%%D\sbigu64.sys" >nul 2>&1
    icacls "%%D\sbigu64.sys" /grant *S-1-5-32-544:F >nul 2>&1
    copy /y "%~dp0sbigu64.sys" "%%D\sbigu64.sys"
)

echo.
echo [6/6] Done!
echo.
echo IMPORTANT: reboot your PC before pluging in your camera.
echo The "Test Mode" will be visible at the next reboot.
pause
